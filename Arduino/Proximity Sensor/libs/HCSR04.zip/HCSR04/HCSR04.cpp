/*
  HC-SR04.h - Library to use the Ultrasonic Module HC-SR04
  Created by Quentin Faivre, March 25, 2016.
*/
#include "Arduino.h"
#include "HCSR04.h"

HCSR04::HCSR04(long trigPin, long echoPin)
{
	_trigPin = trigPin;
	_echoPin = echoPin;
	pinMode(trigPin, OUTPUT);
	pinMode(echoPin, INPUT);
}

void HCSR04::measure()
{
	// The sensor is triggered by a HIGH pulse of 10 or more microseconds.
	// Give a short LOW pulse beforehand to ensure a clean HIGH pulse:
	digitalWrite(_trigPin, LOW);
	delayMicroseconds(5);
	digitalWrite(_trigPin, HIGH);
	delayMicroseconds(10);
	digitalWrite(_trigPin, LOW);
	
	// Read the signal from the sensor: a HIGH pulse whose
	// duration is the time (in microseconds) from the sending
	// of the ping to the reception of its echo off of an object.
	pinMode(_echoPin, INPUT);
	_duration = pulseIn(_echoPin, HIGH)
	
	// Convert time into distance
	_cm = _duration / 58;
	_inches = _duration / 148;
}

long HCSR04::getCm(){
	return(_cm);
}

long HCSR04::getInches(){
	return(_inches);
}
/*
  HC-SR04.h - Library to use the Ultrasonic Module HC-SR04
  Created by Quentin Faivre, March 25, 2016.
*/
#ifndef HCSR04_h
#define HCSR04_h

#include "Arduino.h"

class HCSR04
{
  public:
    HC-SR04(long trigPin, long echoPin);
	void measure();
	long getCm();
	long getInches();
  private:
    int _trigPin;
    int _echoPin;
	long _duration;
	long _cm;
	long _inches;
};

#endif